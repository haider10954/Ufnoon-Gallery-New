<!-- Jquery -->
<script src="{{ asset('web-assets/js/plugins/jquery-1.11.3.min.js') }}"></script>

<!-- Slider Revolution -->
<script src="{{ asset('web-assets/js/plugins/revolution/js/jquery.themepunch.tools.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/revolution/js/jquery.themepunch.revolution.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.actions.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.carousel.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.migration.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.navigation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.parallax.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('web-assets/js/plugins/revolution/js/extensions/revolution.extension.video.min.js') }}"></script>

