<!-- Sricpts -->

<script src="{{ asset('assets/libs/dropzone/min/dropzone.min.js') }}"></script>


<!-- Sweet alert init js-->
<script src="{{ asset('assets/libs/sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ asset('assets/js/pages/sweet-alerts.init.js') }}"></script>

<script src="{{ asset('web-assets/js/plugins/jquery-1.11.3.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/bootstrap.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/modernizr-2.8.3-respond-1.4.2.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/revolution/js/jquery.themepunch.tools.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/revolution/js/jquery.themepunch.revolution.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/owl-carousel/owl.carousel.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/parallax.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/scrollReveal.min.js') }}"></script>
<script src="{{ asset('web-assets/js/plugins/bootstrap-dropdownhover.min.js') }}"></script>


<script src="{{ asset('web-assets/js/parsley.min.js') }}"></script>
<script src="{{ asset('web-assets/js/customajax.js') }}"></script>
<script src="{{ asset('web-assets/js/alertify.js') }}"></script>

<script src="{{ asset('web-assets/js/main.js') }}"></script>
